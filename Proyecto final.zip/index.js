$(function(){
 
    var modal = document.getElementById("myModal"); 
    var span = document.getElementsByClassName("close")[0];
 
    span.onclick = function() {
        modal.style.display = "none";
    }
 
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Ciudad

    var modal2 = document.getElementById("myModal2"); 
    var span2 = document.getElementsByClassName("close2")[0];
 
    span2.onclick = function() {
        modal2.style.display = "none";
    }
 
    window.onclick = function(event) {
        if (event.target == modal2) {
            modal2.style.display = "none";
        }
    }


    $("#temptab").on("click", function(){
        modal.style.display = "block";        
    });


    $("#ciudadtab").on("click", function(){
        modal2.style.display = "block";        
    });


    


    // Poblar tabla

    let tempData = [
        {
            id: "1",
            date: "26/04/2021",
            temp: "16°"
        },
        {
            id: "2",
            date: "25/04/2021",
            temp: "17°"
        },
        {
            id: "3",
            date: "24/04/2021",
            temp: "22°"
        }
    ];

    tempData.forEach(element => {
        const data = `<tr data-id="${element.id}">
        <th scope="row">${element.id}</th>
        <td>${element.date}</td>
        <td>${element.temp}</td>
        <td><button data-id="${element.id}" class="updateTemp btn btnGreen">Actualizar</button><button data-id="${element.id}" class="deleteTemp btn btnRed">Eliminar</button></td>
      </tr>`
      $("#tempTable").append(data);
    }); 

    
    $(".deleteTemp").on("click", function(e){
        console.log(e);
        const id = e.target.getAttribute("data-id");
        console.log(id);
        swal({
            title: "Estas seguro?",
            text: "Vas a eliminar un registro de temperatura",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Si, eliminar!",
            closeOnConfirm: false
          },
        ).then(function (){
            $("tr[data-id='" + id + "']").remove();
            swal("Eliminado!", "Eliminado", "success");        
        });;
    });

});